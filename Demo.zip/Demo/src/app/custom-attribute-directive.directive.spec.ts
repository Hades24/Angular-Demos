import { CustomAttributeDirectiveDirective } from './custom-attribute-directive.directive';

describe('CustomAttributeDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomAttributeDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
