import { PassValidDirective } from './pass-valid.directive';

describe('PassValidDirective', () => {
  it('should create an instance', () => {
    const directive = new PassValidDirective();
    expect(directive).toBeTruthy();
  });
});
