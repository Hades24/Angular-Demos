import { Directive } from '@angular/core';
import {NG_VALIDATORS, Validator} from '@angular/forms';

@Directive({
  selector: '[appPassValid]'
  
})
export class PassValidDirective {

  constructor() { }

}
